package com.example.bda.Email;

public class Util {

    public static final String EMAIL = "bloodtransfusion4@gmail.com";
    public static final String PASSWORD = "kamanza037";

}
